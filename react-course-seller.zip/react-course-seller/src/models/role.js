export const Role = {
    USER: 'USER',
    ADMIN: 'ADMIN'
}
